﻿using System.Reflection;

[assembly: AssemblyVersion("1.1.0")]