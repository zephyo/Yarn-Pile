﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyVersion("2.0.0")]
[assembly: InternalsVisibleTo("YarnSpinnerTests")]
